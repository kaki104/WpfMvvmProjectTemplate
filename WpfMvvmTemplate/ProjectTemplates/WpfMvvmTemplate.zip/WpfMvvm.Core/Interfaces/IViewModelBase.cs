﻿namespace $safeprojectname$.Interfaces
{
    /// <summary>
    /// IViewModelBase
    /// </summary>
    public interface IViewModelBase
    {
        string Title { get; set; }
    }
}