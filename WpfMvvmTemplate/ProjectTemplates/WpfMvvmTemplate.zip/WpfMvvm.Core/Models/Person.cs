using System;

namespace $safeprojectname$
{
    /// <summary>
    /// ��� ������ ��
    /// </summary>
    public class Person
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public bool Sex { get; set; }
        public string Description { get; set; }
    }
}
